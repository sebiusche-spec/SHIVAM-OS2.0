package com.shivamos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor

class ReminderRepository private constructor(context: Context) {

    private val helper = ChronexaDatabase(context)

    companion object {
        @Volatile
        private var instance: ReminderRepository? = null

        fun get(context: Context): ReminderRepository =
            instance ?: synchronized(this) {
                instance ?: ReminderRepository(context.applicationContext).also { instance = it }
            }
    }

    fun getAll(): List<Reminder> {
        val cursor = helper.readableDatabase.query(
            "reminders", null, null, null, null, null, "hour ASC, minute ASC"
        )
        return cursor.use { c ->
            val out = ArrayList<Reminder>()
            while (c.moveToNext()) out.add(c.toReminder())
            out
        }
    }

    fun getById(id: Long): Reminder? {
        val cursor = helper.readableDatabase.query(
            "reminders", null, "id = ?", arrayOf(id.toString()), null, null, null
        )
        return cursor.use { c -> if (c.moveToFirst()) c.toReminder() else null }
    }

    fun insert(reminder: Reminder): Long =
        helper.writableDatabase.insertOrThrow("reminders", null, reminder.toValues())

    fun update(reminder: Reminder): Boolean =
        helper.writableDatabase.update(
            "reminders", reminder.toValues(), "id = ?", arrayOf(reminder.id.toString())
        ) > 0

    fun setEnabled(id: Long, enabled: Boolean): Boolean {
        val values = ContentValues().apply { put("enabled", if (enabled) 1 else 0) }
        return helper.writableDatabase.update("reminders", values, "id = ?", arrayOf(id.toString())) > 0
    }

    fun delete(id: Long): Boolean =
        helper.writableDatabase.delete("reminders", "id = ?", arrayOf(id.toString())) > 0

    private fun Cursor.toReminder(): Reminder = Reminder(
        id = getLong(getColumnIndexOrThrow("id")),
        title = getString(getColumnIndexOrThrow("title")),
        description = getString(getColumnIndexOrThrow("description")),
        category = getString(getColumnIndexOrThrow("category")),
        hour = getInt(getColumnIndexOrThrow("hour")),
        minute = getInt(getColumnIndexOrThrow("minute")),
        repeatType = RepeatType.fromStorage(getString(getColumnIndexOrThrow("repeat_type"))),
        weekdaysMask = getInt(getColumnIndexOrThrow("weekdays_mask")),
        startDate = getString(getColumnIndexOrThrow("start_date")),
        enabled = getInt(getColumnIndexOrThrow("enabled")) == 1,
        createdAt = getLong(getColumnIndexOrThrow("created_at"))
    )

    private fun Reminder.toValues(): ContentValues = ContentValues().apply {
        put("title", title)
        put("description", description)
        put("category", category)
        put("hour", hour)
        put("minute", minute)
        put("repeat_type", repeatType.storageValue)
        put("weekdays_mask", weekdaysMask)
        put("start_date", startDate)
        put("enabled", if (enabled) 1 else 0)
        put("created_at", createdAt)
    }
}
