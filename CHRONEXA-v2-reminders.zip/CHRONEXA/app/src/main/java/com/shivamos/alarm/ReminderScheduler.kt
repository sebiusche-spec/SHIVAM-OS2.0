package com.shivamos.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shivamos.data.Reminder
import com.shivamos.data.ReminderRepository
import com.shivamos.data.ReminderTiming

object ReminderScheduler {

    const val EXTRA_REMINDER_ID = "com.shivamos.extra.REMINDER_ID"
    const val EXTRA_TEST = "com.shivamos.extra.TEST"
    private const val TEST_REQUEST_CODE = 0

    sealed class ScheduleOutcome {
        data class Exact(val triggerMillis: Long) : ScheduleOutcome()
        data class Inexact(val triggerMillis: Long) : ScheduleOutcome()
        object NoUpcoming : ScheduleOutcome()
        object Unavailable : ScheduleOutcome()
    }

    // Replaces any existing alarm for this reminder. Call after every add, edit or enable.
    fun schedule(context: Context, reminder: Reminder): ScheduleOutcome {
        val alarm = context.getSystemService(AlarmManager::class.java)
            ?: return ScheduleOutcome.Unavailable
        cancel(context, reminder.id)
        val trigger = ReminderTiming.nextTriggerMillis(reminder, System.currentTimeMillis())
            ?: return ScheduleOutcome.NoUpcoming
        val pending = pendingFor(
            context,
            reminder.id.toInt(),
            reminderIntent(context, reminder.id),
            create = true
        ) ?: return ScheduleOutcome.Unavailable
        return deliver(alarm, trigger, pending)
    }

    fun cancel(context: Context, reminderId: Long) {
        val alarm = context.getSystemService(AlarmManager::class.java) ?: return
        val existing = pendingFor(
            context,
            reminderId.toInt(),
            reminderIntent(context, reminderId),
            create = false
        ) ?: return
        alarm.cancel(existing)
        existing.cancel()
    }

    // Used by the Reliability screen to check real delivery on this phone.
    fun scheduleTest(context: Context, delayMillis: Long): ScheduleOutcome {
        val alarm = context.getSystemService(AlarmManager::class.java)
            ?: return ScheduleOutcome.Unavailable
        val intent = Intent(context, AlarmReceiver::class.java).putExtra(EXTRA_TEST, true)
        val pending = pendingFor(context, TEST_REQUEST_CODE, intent, create = true)
            ?: return ScheduleOutcome.Unavailable
        alarm.cancel(pending)
        return deliver(alarm, System.currentTimeMillis() + delayMillis, pending)
    }

    // Restores every enabled reminder. Runs after reboot, app update and app start.
    fun rescheduleAll(context: Context) {
        ReminderRepository.get(context).getAll().forEach { reminder ->
            if (reminder.enabled) {
                schedule(context, reminder)
            } else {
                cancel(context, reminder.id)
            }
        }
    }

    private fun deliver(alarm: AlarmManager, trigger: Long, pending: PendingIntent): ScheduleOutcome {
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()
        if (exactAllowed) {
            try {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
                return ScheduleOutcome.Exact(trigger)
            } catch (e: SecurityException) {
                // Fall through to an inexact alarm below.
            }
        }
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
        return ScheduleOutcome.Inexact(trigger)
    }

    private fun reminderIntent(context: Context, reminderId: Long): Intent =
        Intent(context, AlarmReceiver::class.java).putExtra(EXTRA_REMINDER_ID, reminderId)

    private fun pendingFor(context: Context, requestCode: Int, intent: Intent, create: Boolean): PendingIntent? {
        val mode = if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            mode or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
