package com.shivamos.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.shivamos.alarm.ReminderScheduler
import com.shivamos.data.Background
import com.shivamos.data.Reminder
import com.shivamos.data.ReminderRepository
import com.shivamos.data.ReminderTiming
import com.shivamos.data.RepeatType
import com.shivamos.data.Weekdays
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal data class ReminderRow(val reminder: Reminder, val next: Long?)

internal fun formatTime(hour: Int, minute: Int): String =
    String.format(Locale.US, "%02d:%02d", hour, minute)

internal fun formatTrigger(millis: Long): String =
    SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(millis))

internal fun describeRepeat(reminder: Reminder): String = when (reminder.repeatType) {
    RepeatType.NONE -> "Once"
    RepeatType.DAILY -> "Every day"
    RepeatType.WEEKLY -> Weekdays.describe(reminder.weekdaysMask)
}

internal fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

internal fun Context.weightParams(startDp: Int): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginStart = dp(startDp)
    }

internal fun loadRows(context: Context, now: Long = System.currentTimeMillis()): List<ReminderRow> =
    ReminderRepository.get(context).getAll()
        .map { ReminderRow(it, ReminderTiming.nextTriggerMillis(it, now)) }
        .sortedWith(compareBy<ReminderRow>({ it.next == null }, { it.next ?: 0L }))

fun Context.remindersScreen(
    onAdd: () -> Unit,
    onEdit: (Long) -> Unit,
    onOpenReliability: () -> Unit
): View {
    val root = verticalColumn().apply { setPadding(dp(20), dp(8), dp(20), dp(28)) }

    root.addView(textOf("Reminders", 26f, Palette.cyan, bold = true))
    root.addView(
        textOf("One-time and repeating alerts, stored on this phone.", 14f, Palette.textSecondary)
            .apply { setPadding(0, dp(4), 0, 0) }
    )

    val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    buttons.addView(actionButton("New reminder", primary = true) { onAdd() }, weightParams(0))
    buttons.addView(actionButton("Reliability", primary = false) { onOpenReliability() }, weightParams(10))
    root.addView(buttons, matchWrap(18))

    val list = verticalColumn()
    root.addView(list, matchWrap(18))

    val app = applicationContext

    fun load() {
        list.removeAllViews()
        list.addView(textOf("Loading reminders…", 14f, Palette.textSecondary))
        Background.run({ loadRows(app) }) { result ->
            list.removeAllViews()
            result
                .onSuccess { rows ->
                    if (rows.isEmpty()) {
                        list.addView(
                            emptyState(
                                "No reminders yet",
                                "Add one and Chronexa will alert you at the time you choose.",
                                "New reminder"
                            ) { onAdd() },
                            matchWrap(0)
                        )
                    } else {
                        rows.forEach { row ->
                            list.addView(reminderCard(row, onEdit, ::load), matchWrap(12))
                        }
                    }
                }
                .onFailure { e ->
                    list.addView(
                        emptyState(
                            "Could not load reminders",
                            e.message ?: "Unknown error.",
                            "Try again"
                        ) { load() },
                        matchWrap(0)
                    )
                }
        }
    }

    load()
    return root
}

private fun Context.reminderCard(row: ReminderRow, onEdit: (Long) -> Unit, onChanged: () -> Unit): View {
    val reminder = row.reminder
    val next = row.next
    val card = cardContainer(onClick = { onEdit(reminder.id) })

    val top = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    texts.addView(textOf(reminder.title, 17f, Palette.textPrimary, bold = true))
    texts.addView(
        textOf(
            "${formatTime(reminder.hour, reminder.minute)}  ·  ${reminder.category}  ·  ${describeRepeat(reminder)}",
            13f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(4), 0, 0) }
    )

    val missed = reminder.enabled && next == null
    val statusLine = when {
        !reminder.enabled -> "Paused"
        next == null -> "Missed: no upcoming time"
        else -> "Next: ${formatTrigger(next)}"
    }
    texts.addView(
        textOf(statusLine, 13f, if (missed) Palette.pink else Palette.textSecondary)
            .apply { setPadding(0, dp(6), 0, 0) }
    )

    top.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
    top.addView(togglePill(reminder.enabled) { toggleReminder(reminder, !reminder.enabled, onChanged) })
    card.addView(top)
    return card
}

private fun Context.togglePill(isOn: Boolean, onToggle: () -> Unit): TextView =
    textOf(if (isOn) "ON" else "OFF", 13f, if (isOn) Palette.background else Palette.textSecondary, bold = true)
        .apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rippleOn(
                if (isOn) gradientDrawable(intArrayOf(Palette.purple, Palette.cyan), dp(16).toFloat())
                else roundedDrawable(Palette.backgroundSecondary, dp(16).toFloat(), Palette.cardBorder, dp(1))
            )
            isClickable = true
            isFocusable = true
            contentDescription = if (isOn) "Turn reminder off" else "Turn reminder on"
            setOnClickListener { onToggle() }
        }

private fun Context.toggleReminder(reminder: Reminder, enable: Boolean, onChanged: () -> Unit) {
    val app = applicationContext
    Background.run({
        val repository = ReminderRepository.get(app)
        repository.setEnabled(reminder.id, enable)
        if (enable) {
            repository.getById(reminder.id)?.let { ReminderScheduler.schedule(app, it) }
        } else {
            ReminderScheduler.cancel(app, reminder.id)
        }
    }) { result ->
        result.onFailure { e -> toast("Could not update: ${e.message ?: "unknown error"}") }
        onChanged()
    }
}
