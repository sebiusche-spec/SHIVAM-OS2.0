package com.shivamos.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.shivamos.data.RepeatType
import com.shivamos.data.ReminderRepository

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try {
                handle(context, intent)
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun handle(context: Context, intent: Intent) {
        if (intent.getBooleanExtra(ReminderScheduler.EXTRA_TEST, false)) {
            Notifications.showTest(context)
            return
        }

        val id = intent.getLongExtra(ReminderScheduler.EXTRA_REMINDER_ID, -1L)
        if (id <= 0L) return

        val repository = ReminderRepository.get(context)
        val reminder = repository.getById(id) ?: return
        if (!reminder.enabled) return

        Notifications.showReminder(context, reminder)

        if (reminder.repeatType == RepeatType.NONE) {
            // One-time reminders switch off after they fire.
            repository.setEnabled(id, false)
            ReminderScheduler.cancel(context, id)
        } else {
            // Repeating reminders schedule their next occurrence.
            ReminderScheduler.schedule(context, reminder)
        }
    }
}
