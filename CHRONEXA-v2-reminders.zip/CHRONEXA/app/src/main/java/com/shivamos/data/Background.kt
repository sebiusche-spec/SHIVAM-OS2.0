package com.shivamos.data

import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

// Runs database work off the main thread and delivers the result on the main thread.
object Background {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun <T> run(work: () -> T, onResult: (Result<T>) -> Unit) {
        executor.execute {
            val result = runCatching { work() }
            main.post { onResult(result) }
        }
    }
}
