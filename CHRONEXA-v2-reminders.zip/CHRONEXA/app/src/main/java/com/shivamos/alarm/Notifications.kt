package com.shivamos.alarm

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.shivamos.MainActivity
import com.shivamos.R
import com.shivamos.data.Reminder

object Notifications {

    private const val CHANNEL_ID = "chronexa_reminders"
    private const val TEST_NOTIFICATION_ID = 0

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "CHRONEXA study and schedule reminders"
            enableVibration(true)
        }
        manager.createNotificationChannel(channel)
    }

    fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun showReminder(context: Context, reminder: Reminder) {
        val text = reminder.description.ifBlank { "Reminder: ${reminder.category}" }
        post(context, reminder.id.toInt(), reminder.title, text)
    }

    fun showTest(context: Context) {
        post(
            context,
            TEST_NOTIFICATION_ID,
            "CHRONEXA test",
            "If you can read this, reminder notifications reach you."
        )
    }

    private fun post(context: Context, id: Int, title: String, text: String) {
        if (!canPost(context)) return
        ensureChannel(context)

        val openApp = PendingIntent.getActivity(
            context,
            id,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = Notification.Builder(context)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_REMINDER)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId(CHANNEL_ID)
        }

        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        manager.notify(id, builder.build())
    }
}
