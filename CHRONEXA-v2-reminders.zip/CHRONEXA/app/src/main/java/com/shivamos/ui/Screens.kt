package com.shivamos.ui

import android.content.Context
import android.view.View

fun Context.pendingScreen(title: String, message: String, phase: String): View {
    val root = verticalColumn().apply {
        setPadding(dp(20), dp(12), dp(20), dp(28))
    }
    root.addView(cardContainer().apply {
        addView(textOf(title, 20f, Palette.cyan, bold = true))
        addView(textOf(message, 15f, Palette.textSecondary).apply {
            setPadding(0, dp(10), 0, 0)
        })
        addView(textOf(phase, 13f, Palette.textPrimary, bold = true).apply {
            setPadding(0, dp(14), 0, 0)
        })
    }, matchWrap())
    return root
}

fun Context.settingsScreen(onOpenReliability: () -> Unit): View {
    val version = appVersionName()
    val root = verticalColumn().apply {
        setPadding(dp(20), dp(12), dp(20), dp(28))
    }

    root.addView(cardContainer().apply {
        addView(sectionTitle("ABOUT"))
        addView(textOf("CHRONEXA", 20f, Palette.textPrimary, bold = true).apply {
            setPadding(0, dp(8), 0, 0)
        })
        addView(textOf("Version $version", 14f, Palette.textSecondary).apply {
            setPadding(0, dp(4), 0, 0)
        })
        addView(textOf(
            "Reminders are stored on this phone. The app has no internet access and sends nothing to a server.",
            14f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(10), 0, 0) })
    }, matchWrap())

    root.addView(cardContainer().apply {
        addView(sectionTitle("REMINDERS"))
        addView(textOf(
            "Check notification permission, exact alarm access and battery settings that affect reminder timing.",
            14f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(10), 0, 0) })
        addView(
            actionButton("Open reminder reliability", primary = false) { onOpenReliability() },
            matchWrap(14)
        )
    }, matchWrap(16))

    root.addView(cardContainer().apply {
        addView(sectionTitle("APPEARANCE"))
        addView(textOf(
            "Theme: CHRONEXA Neon (dark). Accent colour choice arrives in a later update.",
            14f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(10), 0, 0) })
    }, matchWrap(16))

    return root
}

private fun Context.appVersionName(): String =
    try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }
