package com.shivamos.ui

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.text.InputType
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.shivamos.alarm.ReminderScheduler
import com.shivamos.data.Background
import com.shivamos.data.Reminder
import com.shivamos.data.ReminderRepository
import com.shivamos.data.ReminderTiming
import com.shivamos.data.RepeatType
import com.shivamos.data.Weekdays
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun Context.reminderFormScreen(editingId: Long?, onDone: () -> Unit): View {
    val root = verticalColumn().apply { setPadding(dp(20), dp(8), dp(20), dp(28)) }
    root.addView(textOf("Loading reminder…", 14f, Palette.textSecondary))

    val app = applicationContext
    Background.run({ editingId?.let { ReminderRepository.get(app).getById(it) } }) { result ->
        root.removeAllViews()
        result
            .onSuccess { existing ->
                if (editingId != null && existing == null) {
                    root.addView(
                        emptyState("Reminder not found", "It may have been deleted.", "Go back") { onDone() },
                        matchWrap(0)
                    )
                } else {
                    buildForm(root, existing, onDone)
                }
            }
            .onFailure { e ->
                root.addView(
                    emptyState("Could not open reminder", e.message ?: "Unknown error."),
                    matchWrap(0)
                )
            }
    }
    return root
}

private fun Context.buildForm(root: LinearLayout, existing: Reminder?, onDone: () -> Unit) {
    val now = System.currentTimeMillis()

    val titleField = inputField("Title, for example Physics: Chapter 3", existing?.title.orEmpty(), multiline = false)
    val notesField = inputField("Notes (optional)", existing?.description.orEmpty(), multiline = true)
    val categoryField = inputField("Category", existing?.category ?: "General", multiline = false)

    var startDate: Calendar = existing?.let { ReminderTiming.parseStartDate(it.startDate) }
        ?: ReminderTiming.startOfDay(now)
    var hour = existing?.hour ?: 9
    var minute = existing?.minute ?: 0
    var repeatChoice = existing?.repeatType ?: RepeatType.NONE
    var weekdayMask = existing?.weekdaysMask ?: 0

    val dateValue = textOf("", 16f, Palette.textPrimary, bold = true)
    val timeValue = textOf("", 16f, Palette.cyan, bold = true)
    val preview = textOf("", 14f, Palette.textSecondary)
    val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    val weekdayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    fun currentDraft(): Reminder = Reminder(
        id = existing?.id ?: 0L,
        title = titleField.text.toString().trim(),
        description = notesField.text.toString().trim(),
        category = categoryField.text.toString().trim().ifEmpty { "General" },
        hour = hour,
        minute = minute,
        repeatType = repeatChoice,
        weekdaysMask = if (repeatChoice == RepeatType.WEEKLY) weekdayMask else 0,
        startDate = ReminderTiming.toStorageDate(startDate),
        enabled = true,
        createdAt = existing?.createdAt ?: now
    )

    fun previewText(): String {
        val next = ReminderTiming.nextTriggerMillis(currentDraft(), System.currentTimeMillis())
        return if (next == null) {
            "No upcoming time with these settings. Choose a later date or time."
        } else {
            "Next alert: ${formatTrigger(next)}"
        }
    }

    fun refresh() {
        dateValue.text = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(startDate.time)
        timeValue.text = formatTime(hour, minute)

        chipRow.removeAllViews()
        RepeatType.entries.forEach { type ->
            chipRow.addView(
                choiceChip(type.label, type == repeatChoice) {
                    repeatChoice = type
                    if (type == RepeatType.WEEKLY && weekdayMask == 0) {
                        weekdayMask = Weekdays.bit(startDate.get(Calendar.DAY_OF_WEEK))
                    }
                    refresh()
                },
                chipParams()
            )
        }

        weekdayRow.removeAllViews()
        weekdayRow.visibility = if (repeatChoice == RepeatType.WEEKLY) View.VISIBLE else View.GONE
        val letters = listOf("S", "M", "T", "W", "T", "F", "S")
        (Calendar.SUNDAY..Calendar.SATURDAY).forEach { day ->
            val selected = Weekdays.contains(weekdayMask, day)
            weekdayRow.addView(
                choiceChip(letters[day - 1], selected) {
                    weekdayMask = weekdayMask xor Weekdays.bit(day)
                    refresh()
                },
                chipParams()
            )
        }

        preview.text = previewText()
    }

    fun save() {
        val draft = currentDraft()
        if (draft.title.isEmpty()) {
            titleField.error = "Enter a title"
            return
        }
        if (draft.title.length > 80) {
            titleField.error = "Keep the title under 80 characters"
            return
        }
        if (repeatChoice == RepeatType.WEEKLY && weekdayMask == 0) {
            toast("Choose at least one day of the week.")
            return
        }
        if (ReminderTiming.nextTriggerMillis(draft, System.currentTimeMillis()) == null) {
            toast("That time has already passed. Choose a later date or time.")
            return
        }

        val toSave = draft.copy(enabled = existing?.enabled ?: true)
        val app = applicationContext
        Background.run({
            val repository = ReminderRepository.get(app)
            val id = if (existing == null) {
                repository.insert(toSave)
            } else {
                repository.update(toSave)
                existing.id
            }
            repository.getById(id)?.let { ReminderScheduler.schedule(app, it) }
            id
        }) { result ->
            result
                .onSuccess { onDone() }
                .onFailure { e -> toast("Could not save: ${e.message ?: "unknown error"}") }
        }
    }

    fun confirmDelete(id: Long) {
        AlertDialog.Builder(this)
            .setTitle("Delete this reminder?")
            .setMessage("Its alarm will be cancelled. This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                val app = applicationContext
                Background.run({
                    ReminderScheduler.cancel(app, id)
                    ReminderRepository.get(app).delete(id)
                }) { result ->
                    result
                        .onSuccess { onDone() }
                        .onFailure { e -> toast("Could not delete: ${e.message ?: "unknown error"}") }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun pickerRow(label: String, value: TextView, onClick: () -> Unit): View =
        cardContainer(onClick = onClick).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(
                textOf(label, 14f, Palette.textSecondary),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(value)
        }

    val dateRowView = pickerRow("Date", dateValue) {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                startDate = Calendar.getInstance().apply {
                    clear()
                    set(year, month, day, 0, 0, 0)
                }
                refresh()
            },
            startDate.get(Calendar.YEAR),
            startDate.get(Calendar.MONTH),
            startDate.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    val timeRowView = pickerRow("Time", timeValue) {
        TimePickerDialog(
            this,
            { _, h, m ->
                hour = h
                minute = m
                refresh()
            },
            hour,
            minute,
            DateFormat.is24HourFormat(this)
        ).show()
    }

    val pickers = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    pickers.addView(dateRowView, weightParams(0))
    pickers.addView(timeRowView, weightParams(10))

    val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    buttons.addView(actionButton("Save", primary = true) { save() }, weightParams(0))
    buttons.addView(actionButton("Cancel", primary = false) { onDone() }, weightParams(10))

    root.addView(sectionTitle("TITLE"), matchWrap(0))
    root.addView(titleField, matchWrap(8))
    root.addView(sectionTitle("NOTES"), matchWrap(18))
    root.addView(notesField, matchWrap(8))
    root.addView(sectionTitle("CATEGORY"), matchWrap(18))
    root.addView(categoryField, matchWrap(8))
    root.addView(sectionTitle("DATE AND TIME"), matchWrap(18))
    root.addView(pickers, matchWrap(8))
    root.addView(sectionTitle("REPEAT"), matchWrap(18))
    root.addView(chipRow, matchWrap(8))
    root.addView(weekdayRow, matchWrap(8))
    root.addView(cardContainer().apply { addView(preview) }, matchWrap(18))
    root.addView(buttons, matchWrap(18))

    if (existing != null) {
        root.addView(
            actionButton("Delete reminder", primary = false) { confirmDelete(existing.id) },
            matchWrap(12)
        )
    }

    refresh()
}

private fun Context.inputField(hintText: String, value: String, multiline: Boolean): EditText =
    EditText(this).apply {
        setText(value)
        hint = hintText
        setTextColor(Palette.textPrimary)
        setHintTextColor(Palette.textSecondary)
        textSize = 16f
        inputType = if (multiline) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            InputType.TYPE_CLASS_TEXT
        }
        if (multiline) {
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
        }
        background = roundedDrawable(Palette.backgroundSecondary, dp(14).toFloat(), Palette.cardBorder, dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

private fun Context.choiceChip(text: String, selected: Boolean, onClick: () -> Unit): TextView =
    textOf(text, 14f, if (selected) Palette.background else Palette.textPrimary, bold = true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(12), dp(8), dp(12))
        background = rippleOn(
            if (selected) gradientDrawable(intArrayOf(Palette.purple, Palette.cyan), dp(12).toFloat())
            else roundedDrawable(Palette.backgroundSecondary, dp(12).toFloat(), Palette.cardBorder, dp(1))
        )
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

private fun Context.chipParams(): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
        setMargins(dp(3), 0, dp(3), 0)
    }
