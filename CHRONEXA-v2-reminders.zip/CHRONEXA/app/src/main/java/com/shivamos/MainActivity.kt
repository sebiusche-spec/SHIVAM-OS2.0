package com.shivamos

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.shivamos.alarm.ReminderScheduler
import com.shivamos.data.Background
import com.shivamos.ui.HomeScreen
import com.shivamos.ui.Palette
import com.shivamos.ui.headerBar
import com.shivamos.ui.pendingScreen
import com.shivamos.ui.reliabilityScreen
import com.shivamos.ui.reminderFormScreen
import com.shivamos.ui.remindersScreen
import com.shivamos.ui.scrollable
import com.shivamos.ui.settingsScreen

enum class Destination(val title: String) {
    HOME("CHRONEXA"),
    STUDY("Study Pilot"),
    REMINDERS("Reminders"),
    REMINDER_FORM("Reminder"),
    RELIABILITY("Reminder reliability"),
    AI("AI Assistant"),
    SETTINGS("Settings")
}

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_NOTIFICATIONS = 101
    }

    private lateinit var container: FrameLayout
    private val history = ArrayList<Destination>()
    private var current: Destination = Destination.HOME
    private var homeScreen: HomeScreen? = null
    private var editingReminderId: Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Palette.background
        window.navigationBarColor = Palette.background

        container = FrameLayout(this).apply {
            setBackgroundColor(Palette.background)
        }
        container.setOnApplyWindowInsetsListener { view, insets ->
            applySystemInsets(view, insets)
            insets
        }

        setContentView(container)

        // Reconcile stored reminders with the alarm system on every app start.
        val app = applicationContext
        Background.run({ ReminderScheduler.rescheduleAll(app) }) { }

        show(Destination.HOME)
    }

    override fun onResume() {
        super.onResume()
        when (current) {
            Destination.HOME -> homeScreen?.start()
            Destination.REMINDERS, Destination.RELIABILITY -> show(current)
            else -> Unit
        }
    }

    override fun onPause() {
        homeScreen?.stop()
        super.onPause()
    }

    override fun onDestroy() {
        homeScreen?.stop()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (history.isNotEmpty()) {
            goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (current == Destination.RELIABILITY) show(current)
    }

    @Suppress("DEPRECATION")
    private fun applySystemInsets(view: View, insets: WindowInsets) {
        view.setPadding(
            insets.systemWindowInsetLeft,
            insets.systemWindowInsetTop,
            insets.systemWindowInsetRight,
            insets.systemWindowInsetBottom
        )
    }

    private fun navigate(destination: Destination) {
        history.add(current)
        show(destination)
    }

    private fun openForm(reminderId: Long?) {
        editingReminderId = reminderId
        navigate(Destination.REMINDER_FORM)
    }

    private fun goBack() {
        val previous = history.removeLastOrNull() ?: return
        show(previous)
    }

    private fun show(destination: Destination) {
        homeScreen?.stop()
        homeScreen = null
        current = destination
        container.removeAllViews()
        container.addView(
            buildPage(destination),
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
    }

    private fun buildPage(destination: Destination): View {
        val body: View = when (destination) {
            Destination.HOME -> {
                val home = HomeScreen(this) { target -> navigate(target) }
                val view = home.build()
                home.start()
                homeScreen = home
                view
            }
            Destination.REMINDERS -> remindersScreen(
                onAdd = { openForm(null) },
                onEdit = { id -> openForm(id) },
                onOpenReliability = { navigate(Destination.RELIABILITY) }
            )
            Destination.REMINDER_FORM -> reminderFormScreen(editingReminderId) { goBack() }
            Destination.RELIABILITY -> reliabilityScreen(REQUEST_NOTIFICATIONS)
            Destination.SETTINGS -> settingsScreen { navigate(Destination.RELIABILITY) }
            Destination.STUDY -> pendingScreen(
                "Study Pilot",
                "Subjects, chapters, tasks, the study timer and notes are built in a later update.",
                "Not built yet"
            )
            Destination.AI -> pendingScreen(
                "AI Assistant",
                "Chat, conversation history and voice input are built in a later update.",
                "Not built yet"
            )
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.background)
        }
        if (destination != Destination.HOME) {
            page.addView(headerBar(destination.title) { goBack() })
        }
        page.addView(
            scrollable(body),
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        return page
    }
}
