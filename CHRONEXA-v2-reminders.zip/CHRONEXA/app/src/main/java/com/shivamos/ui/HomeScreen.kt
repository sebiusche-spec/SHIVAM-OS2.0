package com.shivamos.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.shivamos.Destination
import com.shivamos.R
import com.shivamos.data.Background
import com.shivamos.data.ReminderTiming
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HomeScreen(
    private val context: Context,
    private val navigate: (Destination) -> Unit
) {
    private val handler = Handler(Looper.getMainLooper())
    private var greetingView: TextView? = null
    private var dateView: TextView? = null
    private var clockView: TextView? = null
    private var todayValue: TextView? = null
    private var activeValue: TextView? = null
    private var nextValue: TextView? = null
    private var todayList: LinearLayout? = null

    private val minuteTick = Runnable {
        refreshClock()
        scheduleNextMinute()
    }

    fun build(): View {
        val root = context.verticalColumn().apply {
            setPadding(context.dp(20), context.dp(12), context.dp(20), context.dp(28))
        }

        root.addView(brandRow())
        root.addView(heroCard(), context.matchWrap(18))

        root.addView(context.sectionTitle("AT A GLANCE"), context.matchWrap(26))
        root.addView(summaryRow(), context.matchWrap(10))
        root.addView(
            context.textOf(
                "Figures come from your saved reminders. Study figures appear once Study Pilot is built.",
                12f,
                Palette.textSecondary
            ),
            context.matchWrap(8)
        )

        root.addView(context.sectionTitle("QUICK ACTIONS"), context.matchWrap(26))
        root.addView(
            quickAction(R.drawable.ic_alarm, "Reminders", "Create and manage alerts", Destination.REMINDERS),
            context.matchWrap(10)
        )
        root.addView(
            quickAction(R.drawable.ic_study, "Study Pilot", "Class 12 JAC tasks and focus timer", Destination.STUDY),
            context.matchWrap(10)
        )
        root.addView(
            quickAction(R.drawable.ic_chat, "AI Assistant", "Chat and voice input", Destination.AI),
            context.matchWrap(10)
        )
        root.addView(
            quickAction(R.drawable.ic_settings, "Reliability", "Check notifications and alarm settings", Destination.RELIABILITY),
            context.matchWrap(10)
        )

        root.addView(context.sectionTitle("TODAY'S REMINDERS"), context.matchWrap(26))
        val list = context.verticalColumn()
        todayList = list
        list.addView(context.textOf("Loading reminders…", 14f, Palette.textSecondary))
        root.addView(list, context.matchWrap(10))

        root.addView(context.sectionTitle("STUDY TASKS"), context.matchWrap(26))
        root.addView(
            context.emptyState(
                title = "No study tasks yet",
                message = "Tasks you add in Study Pilot will show here with your progress.",
                actionLabel = "Open Study Pilot",
                onAction = { navigate(Destination.STUDY) }
            ),
            context.matchWrap(10)
        )

        loadReminders()
        return root
    }

    fun start() {
        handler.removeCallbacks(minuteTick)
        refreshClock()
        scheduleNextMinute()
    }

    fun stop() {
        handler.removeCallbacks(minuteTick)
    }

    private fun loadReminders() {
        val app = context.applicationContext
        Background.run({ loadRows(app) }) { result ->
            result
                .onSuccess { rows -> renderRows(rows) }
                .onFailure { showListError() }
        }
    }

    private fun renderRows(rows: List<ReminderRow>) {
        val todayRows = rows.filter { row -> row.next?.let { isToday(it) } == true }
        val nextMillis = rows.mapNotNull { it.next }.minOrNull()

        todayValue?.text = todayRows.size.toString()
        activeValue?.text = rows.count { it.reminder.enabled }.toString()
        nextValue?.text = nextMillis
            ?.let { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(it)) }
            ?: "-"

        val list = todayList ?: return
        list.removeAllViews()
        if (todayRows.isEmpty()) {
            list.addView(
                context.emptyState(
                    title = "No reminders today",
                    message = "Reminders scheduled for today will appear here.",
                    actionLabel = "Open Reminders",
                    onAction = { navigate(Destination.REMINDERS) }
                ),
                context.matchWrap(0)
            )
        } else {
            todayRows.take(4).forEach { row ->
                list.addView(todayCard(row), context.matchWrap(10))
            }
        }
    }

    private fun showListError() {
        val list = todayList ?: return
        list.removeAllViews()
        list.addView(context.textOf("Could not load reminders. Open Reminders to try again.", 14f, Palette.pink))
    }

    private fun todayCard(row: ReminderRow): View {
        val card = context.cardContainer(onClick = { navigate(Destination.REMINDERS) })
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.addView(context.textOf(formatTime(row.reminder.hour, row.reminder.minute), 17f, Palette.cyan, bold = true))
        card.addView(
            context.textOf(row.reminder.title, 15f, Palette.textPrimary, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = context.dp(14)
                }
            }
        )
        return card
    }

    private fun isToday(millis: Long): Boolean {
        val today = ReminderTiming.startOfDay(System.currentTimeMillis()).timeInMillis
        return ReminderTiming.startOfDay(millis).timeInMillis == today
    }

    private fun brandRow(): View {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titles = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(context.textOf("CHRONEXA", 26f, Palette.cyan, bold = true))
        titles.addView(context.textOf("REMINDERS  ·  STUDY  ·  AI", 11f, Palette.textSecondary))
        row.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val settings = context.iconView(R.drawable.ic_settings, 24).apply {
            layoutParams = LinearLayout.LayoutParams(context.dp(48), context.dp(48))
            setPadding(context.dp(12), context.dp(12), context.dp(12), context.dp(12))
            background = rippleOn(
                roundedDrawable(Palette.card, context.dp(16).toFloat(), Palette.cardBorder, context.dp(1))
            )
            contentDescription = "Open settings"
            isClickable = true
            isFocusable = true
            setOnClickListener { navigate(Destination.SETTINGS) }
        }
        row.addView(settings)
        return row
    }

    private fun heroCard(): View {
        val card = context.verticalColumn().apply {
            setPadding(context.dp(22), context.dp(22), context.dp(22), context.dp(22))
            background = gradientDrawable(
                intArrayOf(Palette.heroStart, Palette.card),
                context.dp(24).toFloat()
            )
        }

        val greeting = context.textOf("", 22f, Palette.textPrimary, bold = true)
        val date = context.textOf("", 14f, Palette.textSecondary)
        val clock = context.textOf("", 44f, Palette.cyan, bold = true)
        greetingView = greeting
        dateView = date
        clockView = clock

        card.addView(greeting)
        card.addView(date, context.matchWrap(4))
        card.addView(clock, context.matchWrap(14))
        card.addView(
            context.textOf("Your day, organised in one place.", 14f, Palette.textSecondary),
            context.matchWrap(6)
        )
        return card
    }

    private fun summaryRow(): View {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val (todayTile, today) = statTile("Today")
        val (activeTile, active) = statTile("Active")
        val (nextTile, next) = statTile("Next")
        todayValue = today
        activeValue = active
        nextValue = next
        row.addView(todayTile, statParams())
        row.addView(activeTile, statParams())
        row.addView(nextTile, statParams())
        return row
    }

    private fun statTile(label: String): Pair<View, TextView> {
        val value = context.textOf("-", 20f, Palette.cyan, bold = true).apply {
            gravity = Gravity.CENTER
        }
        val tile = context.cardContainer().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            addView(value)
            addView(context.textOf(label, 12f, Palette.textSecondary).apply {
                gravity = Gravity.CENTER
                setPadding(0, context.dp(4), 0, 0)
            })
        }
        return tile to value
    }

    private fun statParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(context.dp(4), 0, context.dp(4), 0)
        }

    private fun quickAction(icon: Int, title: String, subtitle: String, target: Destination): View {
        val row = context.cardContainer(onClick = { navigate(target) }).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        row.addView(context.iconView(icon, 30))

        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(context.textOf(title, 17f, Palette.textPrimary, bold = true))
        texts.addView(context.textOf(subtitle, 13f, Palette.textSecondary).apply {
            setPadding(0, context.dp(3), 0, 0)
        })
        row.addView(
            texts,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = context.dp(14)
            }
        )

        row.addView(context.textOf("›", 24f, Palette.cyan, bold = true))
        return row
    }

    private fun refreshClock() {
        val now = Date()
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greetingView?.text = greetingFor(hour)
        dateView?.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)
        clockView?.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(now)
    }

    private fun scheduleNextMinute() {
        val delay = 60_000L - (System.currentTimeMillis() % 60_000L) + 100L
        handler.postDelayed(minuteTick, delay)
    }

    private fun greetingFor(hour: Int): String = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good night"
    }
}
