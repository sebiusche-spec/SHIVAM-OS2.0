package com.shivamos.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Palette {
    val background: Int = Color.parseColor("#050816")
    val backgroundSecondary: Int = Color.parseColor("#0B1020")
    val card: Int = Color.parseColor("#10182B")
    val cardBorder: Int = Color.parseColor("#22304F")
    val heroStart: Int = Color.parseColor("#2A1257")
    val cyan: Int = Color.parseColor("#00E5FF")
    val purple: Int = Color.parseColor("#8A2BE2")
    val pink: Int = Color.parseColor("#FF2D95")
    val textPrimary: Int = Color.parseColor("#F5F7FF")
    val textSecondary: Int = Color.parseColor("#9BA8C7")
}

fun Context.dp(value: Int): Int =
    (value * resources.displayMetrics.density + 0.5f).toInt()

fun roundedDrawable(
    fill: Int,
    radiusPx: Float,
    strokeColor: Int? = null,
    strokeWidthPx: Int = 0
): GradientDrawable = GradientDrawable().apply {
    setColor(fill)
    setCornerRadius(radiusPx)
    if (strokeColor != null && strokeWidthPx > 0) {
        setStroke(strokeWidthPx, strokeColor)
    }
}

fun gradientDrawable(colors: IntArray, radiusPx: Float): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
        setCornerRadius(radiusPx)
    }

fun rippleOn(content: GradientDrawable): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), content, null)

fun Context.textOf(
    value: String,
    sizeSp: Float,
    color: Int,
    bold: Boolean = false
): TextView = TextView(this).apply {
    text = value
    textSize = sizeSp
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
}

fun Context.sectionTitle(value: String): TextView =
    textOf(value, 12f, Palette.cyan, bold = true).apply {
        letterSpacing = 0.12f
    }

fun Context.verticalColumn(): LinearLayout =
    LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.cardContainer(onClick: (() -> Unit)? = null): LinearLayout {
    val content = roundedDrawable(Palette.card, dp(20).toFloat(), Palette.cardBorder, dp(1))
    return LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        if (onClick != null) {
            background = rippleOn(content)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        } else {
            background = content
        }
    }
}

fun Context.matchWrap(topDp: Int = 0): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dp(topDp)
    }

fun Context.actionButton(
    label: String,
    primary: Boolean = false,
    onClick: () -> Unit
): TextView {
    val fill: GradientDrawable = if (primary) {
        gradientDrawable(intArrayOf(Palette.purple, Palette.cyan), dp(14).toFloat())
    } else {
        roundedDrawable(Palette.backgroundSecondary, dp(14).toFloat(), Palette.cyan, dp(1))
    }
    return textOf(label, 15f, if (primary) Palette.background else Palette.cyan, bold = true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rippleOn(fill)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }
}

fun Context.iconView(resId: Int, sizeDp: Int): ImageView =
    ImageView(this).apply {
        setImageResource(resId)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

fun Context.headerBar(title: String, onBack: (() -> Unit)?): LinearLayout =
    LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(14), dp(20), dp(14))
        if (onBack != null) {
            addView(textOf("‹ Back", 15f, Palette.cyan, bold = true).apply {
                setPadding(dp(8), dp(8), dp(12), dp(8))
                isClickable = true
                isFocusable = true
                setOnClickListener { onBack() }
            })
        }
        addView(
            textOf(title, 18f, Palette.textPrimary, bold = true),
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
    }

fun Context.emptyState(
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
): LinearLayout = cardContainer().apply {
    gravity = Gravity.CENTER_HORIZONTAL
    addView(textOf(title, 16f, Palette.textPrimary, bold = true).apply {
        gravity = Gravity.CENTER
    })
    addView(textOf(message, 14f, Palette.textSecondary).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(6), 0, 0)
    })
    if (actionLabel != null && onAction != null) {
        addView(actionButton(actionLabel, primary = false, onClick = onAction).apply {
            layoutParams = matchWrap(14)
        })
    }
}

fun Context.scrollable(content: View): ScrollView =
    ScrollView(this).apply {
        setBackgroundColor(Palette.background)
        setFillViewport(true)
        addView(content)
    }
