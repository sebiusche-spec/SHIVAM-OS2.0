package com.shivamos.data

import java.util.Calendar
import java.util.Locale

enum class RepeatType(val storageValue: String, val label: String) {
    NONE("none", "Once"),
    DAILY("daily", "Every day"),
    WEEKLY("weekly", "Selected days");

    companion object {
        fun fromStorage(value: String): RepeatType =
            entries.firstOrNull { it.storageValue == value } ?: NONE
    }
}

data class Reminder(
    val id: Long,
    val title: String,
    val description: String,
    val category: String,
    val hour: Int,
    val minute: Int,
    val repeatType: RepeatType,
    val weekdaysMask: Int,
    val startDate: String,
    val enabled: Boolean,
    val createdAt: Long
)

object Weekdays {
    // Bit 0 = Sunday, matching Calendar.SUNDAY = 1.
    fun bit(dayOfWeek: Int): Int = 1 shl (dayOfWeek - 1)

    fun contains(mask: Int, dayOfWeek: Int): Boolean = (mask and bit(dayOfWeek)) != 0

    fun describe(mask: Int): String {
        val names = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        val picked = (Calendar.SUNDAY..Calendar.SATURDAY).filter { contains(mask, it) }
        return if (picked.isEmpty()) "none" else picked.joinToString(", ") { names[it - 1] }
    }
}

object ReminderTiming {
    private const val MAX_DAYS_SCANNED = 800

    fun startOfDay(millis: Long): Calendar = Calendar.getInstance().apply {
        timeInMillis = millis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    fun parseStartDate(value: String): Calendar? {
        val parts = value.split("-")
        if (parts.size != 3) return null
        val year = parts[0].toIntOrNull() ?: return null
        val month = parts[1].toIntOrNull() ?: return null
        val day = parts[2].toIntOrNull() ?: return null
        if (month !in 1..12 || day !in 1..31) return null
        return Calendar.getInstance().apply {
            clear()
            set(year, month - 1, day, 0, 0, 0)
        }
    }

    fun toStorageDate(day: Calendar): String =
        String.format(
            Locale.US,
            "%04d-%02d-%02d",
            day.get(Calendar.YEAR),
            day.get(Calendar.MONTH) + 1,
            day.get(Calendar.DAY_OF_MONTH)
        )

    // Returns the next trigger time in local time, or null if nothing is upcoming.
    // Calendar arithmetic is used so daylight-saving changes are handled by the platform.
    fun nextTriggerMillis(reminder: Reminder, nowMillis: Long): Long? {
        if (!reminder.enabled) return null
        val start = parseStartDate(reminder.startDate) ?: return null
        val today = startOfDay(nowMillis)
        val cursor = Calendar.getInstance().apply {
            timeInMillis = maxOf(today.timeInMillis, start.timeInMillis)
        }
        repeat(MAX_DAYS_SCANNED) {
            if (matchesDay(reminder, cursor, start)) {
                val trigger = Calendar.getInstance().apply {
                    timeInMillis = cursor.timeInMillis
                    set(Calendar.HOUR_OF_DAY, reminder.hour)
                    set(Calendar.MINUTE, reminder.minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                if (trigger > nowMillis) return trigger
            }
            cursor.add(Calendar.DAY_OF_YEAR, 1)
        }
        return null
    }

    private fun matchesDay(reminder: Reminder, day: Calendar, start: Calendar): Boolean {
        if (day.before(start)) return false
        return when (reminder.repeatType) {
            RepeatType.NONE -> sameDay(day, start)
            RepeatType.DAILY -> true
            RepeatType.WEEKLY -> Weekdays.contains(reminder.weekdaysMask, day.get(Calendar.DAY_OF_WEEK))
        }
    }

    private fun sameDay(a: Calendar, b: Calendar): Boolean =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
            a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}
