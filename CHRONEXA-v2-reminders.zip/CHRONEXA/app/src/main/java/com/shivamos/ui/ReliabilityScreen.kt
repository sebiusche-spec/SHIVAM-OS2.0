package com.shivamos.ui

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import com.shivamos.alarm.ReminderScheduler
import java.util.Locale

fun Activity.reliabilityScreen(requestCode: Int): View {
    val root = verticalColumn().apply { setPadding(dp(20), dp(8), dp(20), dp(28)) }

    root.addView(textOf("Reminder reliability", 24f, Palette.cyan, bold = true))
    root.addView(
        textOf(
            "Android decides whether reminders fire on time. Check each item below. Chronexa cannot change these settings for you.",
            14f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(6), 0, 0) }
    )

    root.addView(sectionTitle("STATUS"), matchWrap(22))
    root.addView(notificationCard(requestCode), matchWrap(10))
    root.addView(exactAlarmCard(), matchWrap(10))
    root.addView(batteryCard(), matchWrap(10))
    root.addView(makerCard(), matchWrap(10))

    root.addView(sectionTitle("TEST REMINDER"), matchWrap(22))
    root.addView(testCard(), matchWrap(10))

    root.addView(sectionTitle("IF A REMINDER DOES NOT APPEAR"), matchWrap(22))
    root.addView(troubleshootingCard(), matchWrap(10))

    return root
}

private fun Activity.notificationCard(requestCode: Int): View {
    val runtimeGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val manager = getSystemService(NotificationManager::class.java)
    val systemEnabled = Build.VERSION.SDK_INT < Build.VERSION_CODES.N ||
        manager?.areNotificationsEnabled() != false

    return when {
        !runtimeGranted -> statusCard(
            "Notifications",
            "Permission not granted",
            false,
            "Allow notifications so reminders can appear. If no prompt shows, the permission may have been refused before. Use the notification settings option below instead.",
            "Allow notifications"
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode)
        }
        !systemEnabled -> statusCard(
            "Notifications",
            "Turned off for Chronexa",
            false,
            "Switch notifications on in the app notification settings.",
            "Open notification settings"
        ) {
            openSystemPage(appNotificationIntent())
        }
        else -> statusCard(
            "Notifications",
            "Allowed",
            true,
            "Chronexa can show reminder alerts. Sound and banner style are controlled by Android notification settings.",
            null,
            null
        )
    }
}

private fun Activity.exactAlarmCard(): View {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
        return statusCard(
            "Exact alarms",
            "Not required",
            true,
            "This Android version allows reminders to use exact timing without an extra permission.",
            null,
            null
        )
    }
    val alarm = getSystemService(AlarmManager::class.java)
    val allowed = alarm?.canScheduleExactAlarms() == true
    return if (allowed) {
        statusCard(
            "Exact alarms",
            "Allowed",
            true,
            "Reminders can fire at the scheduled minute.",
            null,
            null
        )
    } else {
        statusCard(
            "Exact alarms",
            "Not allowed",
            false,
            "Without exact alarm access, Android may delay reminders by several minutes to save battery.",
            "Allow exact alarms"
        ) {
            openSystemPage(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.fromParts("package", packageName, null))
            )
        }
    }
}

private fun Activity.batteryCard(): View {
    val power = getSystemService(PowerManager::class.java)
    val unrestricted = power?.isIgnoringBatteryOptimizations(packageName) == true
    return if (unrestricted) {
        statusCard(
            "Battery optimisation",
            "Not restricted",
            true,
            "Android is not limiting Chronexa's background work for battery.",
            null,
            null
        )
    } else {
        statusCard(
            "Battery optimisation",
            "Optimised by Android",
            false,
            "Battery optimisation can delay reminders while the phone is idle. Open the battery list and choose No restrictions or Unrestricted for Chronexa.",
            "Open battery settings"
        ) {
            openSystemPage(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
}

private fun Activity.makerCard(): View {
    val maker = Build.MANUFACTURER.lowercase(Locale.US)
    val xiaomiFamily = listOf("xiaomi", "poco", "redmi").any { maker.contains(it) }
    val text = if (xiaomiFamily) {
        "Xiaomi, Redmi and POCO phones (HyperOS or MIUI): open Settings, then Apps, then Manage apps, then CHRONEXA. Set Battery saver to No restrictions. Turn on Autostart if the option is shown. In the recent apps view, lock CHRONEXA so it is not cleared. Menu names differ between versions, and the phone's system controls these switches, so Chronexa cannot change them for you."
    } else {
        "Some phone makers add their own power management. Look for Battery saver, Autostart or Background activity under Settings, then Apps, then CHRONEXA, and allow background activity. Chronexa cannot change these switches for you."
    }

    val card = cardContainer()
    card.addView(textOf("Phone-maker settings", 16f, Palette.textPrimary, bold = true))
    card.addView(textOf(text, 14f, Palette.textSecondary).apply { setPadding(0, dp(8), 0, 0) })
    card.addView(
        actionButton("Open app details", primary = false) { openSystemPage(appDetailsIntent()) },
        matchWrap(12)
    )
    return card
}

private fun Activity.testCard(): View {
    val card = cardContainer()
    val result = textOf("No test sent yet.", 14f, Palette.textSecondary)
        .apply { setPadding(0, dp(10), 0, 0) }

    card.addView(textOf("Sends a real test notification 10 seconds from now.", 14f, Palette.textPrimary, bold = true))
    card.addView(
        textOf(
            "Press the button, then lock the phone and wait. The notification should appear. If it does not, check the statuses above and the notes below.",
            13f,
            Palette.textSecondary
        ).apply { setPadding(0, dp(6), 0, 0) }
    )
    card.addView(
        actionButton("Send test in 10 seconds", primary = true) {
            result.text = when (ReminderScheduler.scheduleTest(applicationContext, 10_000L)) {
                is ReminderScheduler.ScheduleOutcome.Exact ->
                    "Test scheduled with exact timing. Lock the phone now."
                is ReminderScheduler.ScheduleOutcome.Inexact ->
                    "Test scheduled, but exact timing is not allowed. It may arrive a few minutes late."
                else ->
                    "Could not schedule the test on this phone. Check the statuses above."
            }
        },
        matchWrap(14)
    )
    card.addView(result)
    return card
}

private fun Context.troubleshootingCard(): View {
    val card = cardContainer()
    card.addView(textOf("Checklist", 16f, Palette.textPrimary, bold = true))
    val notes = listOf(
        "Check that notifications are allowed for Chronexa, both above and in Android settings.",
        "Turn off Do Not Disturb or Focus mode while testing.",
        "Turn off Battery saver for Chronexa and keep it unrestricted in the background.",
        "Do not force-stop Chronexa. Android cancels its scheduled alarms when an app is force-stopped, until you open it again.",
        "After a restart, reminders are restored once you unlock the phone for the first time.",
        "Some phones delay alarms more than others. Exact alarm access and an unrestricted battery setting give the best chance of on-time alerts, but no app can guarantee delivery under every condition."
    )
    notes.forEach { note ->
        card.addView(textOf(note, 13f, Palette.textSecondary).apply { setPadding(0, dp(8), 0, 0) })
    }
    return card
}

private fun Context.statusCard(
    title: String,
    status: String,
    ok: Boolean,
    detail: String,
    actionLabel: String?,
    onAction: (() -> Unit)?
): View {
    val card = cardContainer()
    val header = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    header.addView(
        textOf(title, 16f, Palette.textPrimary, bold = true),
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    )
    header.addView(textOf(if (ok) "OK" else "ACTION", 12f, if (ok) Palette.cyan else Palette.pink, bold = true))
    card.addView(header)
    card.addView(
        textOf(status, 14f, if (ok) Palette.textPrimary else Palette.pink, bold = true)
            .apply { setPadding(0, dp(8), 0, 0) }
    )
    card.addView(textOf(detail, 13f, Palette.textSecondary).apply { setPadding(0, dp(6), 0, 0) })
    if (actionLabel != null && onAction != null) {
        card.addView(actionButton(actionLabel, primary = false) { onAction() }, matchWrap(12))
    }
    return card
}

private fun Context.appNotificationIntent(): Intent =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    } else {
        appDetailsIntent()
    }

private fun Context.appDetailsIntent(): Intent =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))

private fun Context.openSystemPage(intent: Intent) {
    try {
        startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        toast("This settings page is not available on this phone.")
    }
}
